
package javadebate;

class JOptionPane {
    
}
