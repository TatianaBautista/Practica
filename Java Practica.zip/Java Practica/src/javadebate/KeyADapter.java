
package javadebate;

public class KeyADapter {
    
}
