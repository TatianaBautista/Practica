/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javadebate;
import javax.swing.JTextField;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;

public class Validaciones {
    public void SoloLetras(JTextField cam){
        cam.addKeyListener(new KeyAdapter(){
            public void keyTyped(KeyEvent e){
                char c=e.getKeyChar();
                if(Character.isDigit(c)){
                    e.consume();
                    JOptionPane.showMessageDialog(null,"SOLO LETRAS");
                }
            }
        });
    }
    
    
    public void SoloNumeros(final JTextField cam){
        cam.addKeyListener(new KeyAdapter(){
            public void keyTyped(KeyEvent e){
                int aux=-1;
                char c=e.getKeyChar();
                if(c=='.'){
                        aux++;
                    }
                if((!Character.isDigit(c) && c!='.')  ||(c=='.'&& cam.getText().contains("."))){
                    e.consume();
                    JOptionPane.showMessageDialog(null,"SOLO NUMEROS ¡GRACIAS!!");
                    
                }
            }
        });
    }
    
   public void longitud(final JTextField cam,final int lim){
        cam.addKeyListener(new KeyAdapter(){
            public void keyTyped(KeyEvent e){
                int can=cam.getText().length();
                if(can>lim){
                    e.consume();
                    JOptionPane.showMessageDialog(null,"CARACTERES MAX ");
                }
            }
        });
    } 
    
}
