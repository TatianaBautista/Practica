
package javadebate;

public class JavaMain {

    
    public static void main(String[] args) {
        
        new JavaDebate().setVisible(true);
    }
    
}
