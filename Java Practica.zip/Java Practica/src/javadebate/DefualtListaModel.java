
package javadebate;

class DefualtListaModel {
    
}
